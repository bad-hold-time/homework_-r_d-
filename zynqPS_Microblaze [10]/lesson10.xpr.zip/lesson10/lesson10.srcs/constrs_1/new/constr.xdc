# led output
set_property -dict {PACKAGE_PIN T11 IOSTANDARD LVCMOS33} [get_ports {leds_tri_o[0]}]
set_property -dict {PACKAGE_PIN T10 IOSTANDARD LVCMOS33} [get_ports {leds_tri_o[1]}]
set_property -dict {PACKAGE_PIN T12 IOSTANDARD LVCMOS33} [get_ports {leds_tri_o[2]}]
set_property -dict {PACKAGE_PIN U12 IOSTANDARD LVCMOS33} [get_ports {leds_tri_o[3]}]
# btn input
set_property -dict {PACKAGE_PIN W13 IOSTANDARD LVCMOS33 PULLUP TRUE} [get_ports {btns_tri_i[0]}]
set_property -dict {PACKAGE_PIN T14 IOSTANDARD LVCMOS33 PULLUP TRUE} [get_ports {btns_tri_i[1]}]
set_property -dict {PACKAGE_PIN T15 IOSTANDARD LVCMOS33 PULLUP TRUE} [get_ports {btns_tri_i[2]}]
set_property -dict {PACKAGE_PIN V12 IOSTANDARD LVCMOS33 PULLUP TRUE} [get_ports {btns_tri_i[3]}]
#sw 
set_property -dict {PACKAGE_PIN M20 IOSTANDARD LVCMOS33 PULLUP TRUE} [get_ports {gpio_rtl_0_tri_i[0]}]
set_property -dict {PACKAGE_PIN M19 IOSTANDARD LVCMOS33 PULLUP TRUE} [get_ports {gpio_rtl_0_tri_i[1]}]