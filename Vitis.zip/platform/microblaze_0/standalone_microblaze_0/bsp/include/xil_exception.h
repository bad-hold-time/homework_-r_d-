/******************************************************************************
* Copyright (C) 2009 - 2021 Xilinx, Inc.  All rights reserved.
* Copyright (C) 2023 - 2026 Advanced Micro Devices, Inc. All Rights Reserved.
* SPDX-License-Identifier: MIT
******************************************************************************/

/*****************************************************************************/
/**
*
* @file xil_exception.h
*
* @addtogroup microblaze_exception_apis Microblaze Exception APIs
* @{
*
* The xil_exception.h file, available in the <install-directory>/src/microblaze folder,
* contains Microblaze specific exception related APIs and macros. Application programs
* can use these APIs for various exception related operations. For example, enable exception,
* disable exception, register exception handler.
*
* @note To use exception related functions, xil_exception.h must be added in source code
*
*
* <pre>
* MODIFICATION HISTORY:
*
* Ver   Who  Date     Changes
* ----- ---- -------- -------------------------------------------------------
* 1.00  hbm  07/28/09 Initial release
* 9.0   ml   03/03/23 Add description to fix doxygen warnings.
* 9.5   ml   04/23/26 Add XIL_EXCEPTION_ALL, mask/save/restore APIs (CR-1262632).
* </pre>
*
******************************************************************************/

/**
 *@cond nocomments
 */
#ifndef XIL_EXCEPTION_H /**< prevent circular inclusions */
#define XIL_EXCEPTION_H /**< by using protection macros */

#include "xil_types.h"

#ifdef __cplusplus
extern "C" {
#endif

/************************** Constant Definitions *****************************/

/*
 * These constants are specific to Microblaze processor.
 */

#define XIL_EXCEPTION_ID_FIRST                0U
#define XIL_EXCEPTION_ID_FSL                  0U
#define XIL_EXCEPTION_ID_UNALIGNED_ACCESS     1U
#define XIL_EXCEPTION_ID_ILLEGAL_OPCODE       2U
#define XIL_EXCEPTION_ID_M_AXI_I_EXCEPTION    3U
#define XIL_EXCEPTION_ID_IPLB_EXCEPTION       3U
#define XIL_EXCEPTION_ID_M_AXI_D_EXCEPTION    4U
#define XIL_EXCEPTION_ID_DPLB_EXCEPTION       4U
#define XIL_EXCEPTION_ID_DIV_BY_ZERO          5U
#define XIL_EXCEPTION_ID_FPU                  6U
#define XIL_EXCEPTION_ID_STACK_VIOLATION      7U
#define XIL_EXCEPTION_ID_MMU                  7U
#define XIL_EXCEPTION_ID_LAST		      XIL_EXCEPTION_ID_MMU
#define XIL_EXCEPTION_MASK		      0x100U
#define XIL_INTERRUPTS_MASK		      0x2U
/**
 * @def XIL_EXCEPTION_ALL
 * @brief Combined mask of all interrupt and hardware exception enable
 *        bits in the MicroBlaze MSR (IE | EE).
 *
 * Used with Xil_ExceptionEnableMask(), Xil_ExceptionDisableMask(),
 * Xil_ExceptionSaveDisable(), and Xil_ExceptionRestoreEnable().
 */
#define XIL_EXCEPTION_ALL (XIL_INTERRUPTS_MASK | XIL_EXCEPTION_MASK)
/*
 * XIL_EXCEPTION_ID_INT is defined for all processors, but with different value.
 */
#define XIL_EXCEPTION_ID_INT		      16U /**
						  * exception ID for interrupt
						  */

/**************************** Type Definitions *******************************/

/**
 * This typedef is the exception handler function.
 */
typedef void (*Xil_ExceptionHandler)(void *Data);

/**
 * This data type defines an interrupt handler for a device.
 * The argument points to the instance of the component
 */
typedef void (*XInterruptHandler) (void *InstancePtr);

/***************** Macros (Inline Functions) Definitions *********************/


/************************** Function Prototypes ******************************/

extern void Xil_ExceptionRegisterHandler(u32 Exception_id,
					 Xil_ExceptionHandler Handler,
					 void *Data);

extern void Xil_ExceptionRemoveHandler(u32 Exception_id);

extern void Xil_ExceptionInit(void);
extern void Xil_ExceptionEnable(void);
extern void Xil_ExceptionDisable(void);

extern void Xil_ExceptionEnableMask(u32 Mask);
extern void Xil_ExceptionDisableMask(u32 Mask);
extern u32 Xil_ExceptionSaveDisable(void);
extern void Xil_ExceptionRestoreEnable(u32 flags);

#ifdef __cplusplus
}
#endif

#endif

/**
 *@endcond
 */

/**
* @} End of "addtogroup microblaze_exception_apis".
*/
