
#include "xparameters.h"
#include "xil_io.h"
#include "xil_types.h"

#ifdef XPAR_AXI_GPIO_0_BASEADDR
  #define GPIO_BASE  XPAR_AXI_GPIO_0_BASEADDR
#else
  #define GPIO_BASE  0x40000000U
#endif

#ifdef XPAR_AXI_DMA_0_BASEADDR
  #define DMA_BASE   XPAR_AXI_DMA_0_BASEADDR
#else
  #define DMA_BASE   0x41E00000U
#endif
#define FRAME_W      320U
#define FRAME_H      200U
#define FRAME_BYTES  (FRAME_W * FRAME_H)
#define FRAME_ADDR   0x00010000U


#define BUTTON_ACTIVE  1U
#define GPIO_DATA    0x00U 
#define GPIO_TRI     0x04U
#define GPIO2_DATA   0x08U  
#define GPIO2_TRI    0x0CU
#define S2MM_DMACR   0x30U
#define S2MM_DMASR   0x34U
#define S2MM_DA      0x48U
#define S2MM_LENGTH  0x58U

#define DMACR_RS     0x00000001U
#define DMACR_RESET  0x00000004U
#define DMASR_IOC    0x00001000U 
#define DMASR_ERRS   0x00000070U 


volatile u32 g_dma_status = 0;
volatile u32 g_received   = 0;

static void dma_reset(void)
{
    Xil_Out32(DMA_BASE + S2MM_DMACR, DMACR_RESET);
    while (Xil_In32(DMA_BASE + S2MM_DMACR) & DMACR_RESET) { }
}

static void dma_s2mm_start(u32 dst_addr, u32 len_bytes)
{
    Xil_Out32(DMA_BASE + S2MM_DMACR, DMACR_RS);
    Xil_Out32(DMA_BASE + S2MM_DMASR, 0x00007000U);
    Xil_Out32(DMA_BASE + S2MM_DA, dst_addr);
    Xil_Out32(DMA_BASE + S2MM_LENGTH, len_bytes);
}
static u32 dma_s2mm_wait(void)
{
    u32 sr;
    do {
        sr = Xil_In32(DMA_BASE + S2MM_DMASR);
    } while ((sr & (DMASR_IOC | DMASR_ERRS)) == 0);
    return sr;
}

static int button_pressed(void)
{
    return ((Xil_In32(GPIO_BASE + GPIO_DATA) & 0x1U) == BUTTON_ACTIVE);
}

int main(void)
{
    Xil_Out32(GPIO_BASE + GPIO_TRI,   0x1U);
    Xil_Out32(GPIO_BASE + GPIO2_TRI,  0x0U);
    Xil_Out32(GPIO_BASE + GPIO2_DATA, 0x0U); 
    while (!button_pressed()) { }
    dma_reset();
    dma_s2mm_start(FRAME_ADDR, FRAME_BYTES);
    Xil_Out32(GPIO_BASE + GPIO2_DATA, 0x1U);
    g_dma_status = dma_s2mm_wait();
    g_received   = Xil_In32(DMA_BASE + S2MM_LENGTH); 
    Xil_Out32(GPIO_BASE + GPIO2_DATA, 0x0U);

    while (1) { }
    return 0;
}